from __future__ import absolute_import
from os import path
import logging
import logging.config
# from .config import config
from .biomodel import *
from .calculation import *
from .checker import *
# from .config.config import *
# from .config import enum
from .config import filename
from .config import flag
from .dataset import *
from .grid import *
# from .gui import *
from .plotter import *
from .project import *
from .result import *
from .solution import *
from .tank import *


__all__ = [  # 所有上述模块导入到此处, 共享变量
    'biomodel',
    'calculation',
    'checker',
    'dataset',
    # 'enum',
    'grid',
    # 'gui',
    'ic',
    'filename',
    'flag',
    'plotter',
    'project',
    'result',
    'solution',
    'tank'
]


# config logger
"""
    logging配置文件

    定义logger模块, root是父类, 必须存在, 其他的自定义
    logging。getLogger(name) 相当于向loggging模块注册了一种日志打印
    如果name为loggers里面keys的值, 则调用对应的配置, 如果name没有则调用默认(root)的配置
    name 中用点 . 表示继承关系
    可以有多个, 以逗号隔开

    实现logger对应的配置信息
                必须是 logger_name  name为loggers中key的值
    level       日志级别, 级别有 DEBUG,INFO,WARNING,ERROR,CRITICAL
    handlers    日志处理器, 可以有多个 以逗号隔开
    qualname    logger的名称, 通过logging.getLogger(name)获取, 这里的name便是qualname
                如果获取的logger 名称不存在, 则调用默认(root)logger
    propagate   是否继承符类的配置信息, 0:否 1: 是

    在这里 如果propagate=1,则表示继承父类(root)的配置信息。
    也就是说 既输出到控制台(继承父类的配置）又输出到日志文件
    propagate = 0 表示仅使用自身的配置, 仅输出到日志文件

    handlers的具体配置实现
    必须是 handler_name  name为handlers中key的值
    class为logging包里面的handler处理器
    formatter 日志输入格式
    args handler相关参数

    日志输出格式化实现
    datefmt 日期格式 对应asctime
    ----------------------------
    日志格式
    ----------------------------
    %(asctime)s      年-月-日 时-分-秒, 毫秒
    %(filename)s     文件名, 不含目录
    %(pathname)s     目录名, 完整路径
    %(funcName)s     函数名
    %(levelname)s    级别名
    %(lineno)d       行号
    %(module)s       模块名
    %(message)s      日志信息
    %(name)s         日志模块名
    %(process)d      进程id
    %(processName)s  进程名
    %(thread)d       线程id
    %(threadName)s   线程名
    ----------------------------
"""
log_file_path = path.join(path.dirname(path.abspath(__file__)), 'config', 'logger.conf')
logging.config.fileConfig(log_file_path)  # 注册 logger sludge



# # 把初始的保留字进行小写转化, 然后统一比较
# _FLAG = config.flag()
# RESERVED_WORDS: list = [  # words cannot be used by ueser, i.e. cannot name a tank 'Tank'
#     words.lower() for words in _FLAG['reserved_words']
# ]



# from .ic import ic
# from .config import *
# from .treatment import *
# ic()
# ic = ic


# def time_format():
#     # return f'{datetime.now()}> '
#     # return f'[{str(datetime.now())[11:23]}] '  # 只显示 小时:分钟:秒
#     return f'{str(datetime.now())[11:23]}> '  # 只显示 小时:分钟:秒


# from icecream import ic  # 全局设定, 包括 sludge_pro
# if getenv('FLASK_CONFIG') == 'production':  # 生产环境
#     ic.disable()  # ic 会覆盖 import 的程序中, 所以开发完成后必须关闭
# else:  # 其他, 比如开发环境
#     ic.configureOutput(includeContext=True, prefix=time_format)  # print with line number and time
#     ic.enable()  # http://www.voidcc.com/project/gruns-icecream

# # def ic():
#     # pass
# ic()

# ic = ic




# def _get_reserved_words(reserved_words: list) -> list:
#     """把初始的保留字进行小写转化, 然后统一比较
#         reserved_word: words cannot be used by ueser, i.e. cannot name a tank 'Tank'
#     """
#     # wu = [words.upper() for words in reserved_words]  # uppercase letter
#     # wc = [words.capitalize() for words in reserved_words]  # first letter to capital
#     # wt = [words.title() for words in reserved_words]  # every word first letter to capital
#     # return reserved_words + wu + wl + wc + wt
#     return [words.lower() for words in reserved_words]  # lowercase letter

# RESERVED_WORDS: list = _get_reserved_words(_FLAG['reserved_words'])




