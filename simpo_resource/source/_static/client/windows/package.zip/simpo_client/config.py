VERSION: str = '0.5.0'


ENV: str = 'prod'  # 生产环境
# ENV: str = 'dev'  # 开发环境
