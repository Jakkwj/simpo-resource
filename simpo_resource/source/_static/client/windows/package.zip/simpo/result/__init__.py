# from __future__ import absolute_import  # 开启绝对引入, 可用 import string 来引入系统的 string, 用 from pkg import string 引入当前目录下的 string
from ._result import *


# __all__ = [  # 哪些函数可通过 from module import * 语句导入到其他模块中
#     'Result',
# ]
